First Android Master/Detail App
================================

First universal master/detail application for Android tablets and phones that incorporates custom data. Documentation is located at www.mobileappdocs.com.
